import base64
import json
import os
import time
import uuid

import boto3

s3 = boto3.client("s3")
BUCKET_NAME = os.environ.get("BUCKET_NAME")


def lambda_handler(event, context):
    """
    Ingest buoy readings from HTTP API Gateway and write to S3.

    Supports both:
      - New flat format from ESP32:
        {"buoy_id":1,"lat":"1.41430","lon":"104.039","reading":1.000}
      - Original nested format:
        {"buoy_id":"B001","coordinates":{"lat":1.35,"lon":103.82},"sensor_data":{"oil_detected":false}}
    """
    # Parse JSON body
    try:
        body = event.get("body")
        if event.get("isBase64Encoded"):
            body = base64.b64decode(body).decode("utf-8")

        data = json.loads(body or "{}")
    except Exception as e:
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Invalid JSON: {str(e)}"}),
        }

    # Normalize flat ESP32 format into nested structure the rest of the pipeline expects
    # Flat example: {"buoy_id":1,"lat":"1.41430","lon":"104.039","reading":1.000}
    if "coordinates" not in data:
        if "lat" in data and "lon" in data:
            try:
                lat_val = float(data["lat"])
            except Exception:
                lat_val = data["lat"]
            try:
                lon_val = float(data["lon"])
            except Exception:
                lon_val = data["lon"]
            data["coordinates"] = {"lat": lat_val, "lon": lon_val}

    if "sensor_data" not in data and "reading" in data:
        # Wrap the numeric reading into sensor_data for downstream processing
        data["sensor_data"] = {"reading": data["reading"]}

    # Basic validation after normalization
    required_fields = ["buoy_id", "coordinates", "sensor_data"]
    missing = [f for f in required_fields if f not in data]
    if missing:
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Missing fields: {', '.join(missing)}"}),
        }

    buoy_id = str(data["buoy_id"])
    # Use provided timestamp or generate current time
    if data.get("timestamp"):
        timestamp = str(data["timestamp"]).replace(":", "-")
        timestamp_iso = data["timestamp"]  # Keep original format for JSON
    else:
        timestamp_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        timestamp = timestamp_iso.replace(":", "-")
        # Add generated timestamp to the data before saving
        data["timestamp"] = timestamp_iso

    # S3 key: raw/buoy-id=<id>/timestamp-<uuid>.json
    key = f"raw/buoy-id={buoy_id}/{timestamp}-{uuid.uuid4().hex}.json"

    if not BUCKET_NAME:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "BUCKET_NAME env var not set"}),
        }

    try:
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=key,
            Body=json.dumps(data).encode("utf-8"),
            ContentType="application/json",
        )
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Failed to write to S3: {str(e)}"}),
        }

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"message": "ok", "s3_key": key}),
    }