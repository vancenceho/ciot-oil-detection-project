import json
import os
import time
import uuid

import boto3

s3 = boto3.client("s3")
BUCKET_NAME = os.environ.get("BUCKET_NAME")


def lambda_handler(event, context):
    # Expect HTTP API Gateway v2 event with JSON body
    try:
        body = event.get("body")
        if event.get("isBase64Encoded"):
            body = base64.b64decode(body).decode("utf-8")

        data = json.loads(body or "{}")
    except Exception as e:
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Invalid JSON: {str(e)}"}),
        }

    # Basic validation (you can extend this)
    required_fields = ["buoy_id", "coordinates", "sensor_data"]
    missing = [f for f in required_fields if f not in data]
    if missing:
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Missing fields: {', '.join(missing)}"}),
        }

    buoy_id = str(data["buoy_id"])
    # Use provided timestamp or generate current time
    if data.get("timestamp"):
        timestamp = str(data["timestamp"]).replace(":", "-")
        timestamp_iso = data["timestamp"]  # Keep original format for JSON
    else:
        timestamp_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        timestamp = timestamp_iso.replace(":", "-")
        # Add generated timestamp to the data before saving
        data["timestamp"] = timestamp_iso

    # S3 key: raw/buoy-id=<id>/timestamp-<uuid>.json
    key = f"raw/buoy-id={buoy_id}/{timestamp}-{uuid.uuid4().hex}.json"

    if not BUCKET_NAME:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "BUCKET_NAME env var not set"}),
        }

    try:
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=key,
            Body=json.dumps(data).encode("utf-8"),
            ContentType="application/json",
        )
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Failed to write to S3: {str(e)}"}),
        }

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"message": "ok", "s3_key": key}),
    }